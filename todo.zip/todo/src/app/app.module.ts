import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TodoComponent } from './Todo/todo.component';
import { RegisterComponent } from './register/register.component';
import { SearchComponent } from './search/search.component';
import { RouterModule, Routes} from '@angular/router';
import{ HttpClientModule} from '@angular/common/http'
const routes: Routes = [

  {path:'', component:TodoComponent},
  { path:'additem', component:RegisterComponent},
  {path:'search', component:SearchComponent},
  { path: '**', component:TodoComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    TodoComponent,
    RegisterComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule, RouterModule.forRoot(routes),HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
