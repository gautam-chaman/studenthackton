export class Todo{
    content:string;
    completed:boolean;
}