import { Component, OnInit } from '@angular/core';
import { usermodel } from '../usermodel';
import {  MyserviceService} from '../myservice.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 
 
  objuser:usermodel = new usermodel();
  constructor(private  MyserviceService: MyserviceService) { }

  ngOnInit(): void {
  }
onSubmit(){
  
  this.MyserviceService.enroll(this.objuser).subscribe(
    
    data=>console.log('success',data),
    error=> console.log('error', error)
  )

}
}
