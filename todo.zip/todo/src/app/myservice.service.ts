import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { usermodel } from './usermodel';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
url='http://localhost:5000/enroll'
  constructor(private httpclient:HttpClient) { }
enroll(user: usermodel){
  return this.httpclient.post<any>(this.url,user)

}


}
