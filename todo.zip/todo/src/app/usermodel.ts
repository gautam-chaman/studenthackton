export class usermodel{
public mobile:number;
public name:string;
public address:string;
public email:string;

}